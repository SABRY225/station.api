const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const path = require('path');
const connectDB = require('./config/db');

// تحميل المتغيرات البيئية
dotenv.config();

// الاتصال بقاعدة البيانات
connectDB();

const app = express();

// الـ Middlewares العامة
app.use(cors());
app.use(express.json()); // لقراءة الـ JSON body

// جعل مجلد الـ uploads عام ومتاح لتحميل وقراءة الملفات منه عبر المتصفح
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// تعريف المسارات (API Routes)
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/topics', require('./routes/topicRoutes'));
app.use('/api/stations', require('./routes/stationRoutes'));

// تشغيل السيرفر
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});